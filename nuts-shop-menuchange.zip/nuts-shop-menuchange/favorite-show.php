<?php session_start(); ?>
<?php require './header.php'; ?>
<?php require 'menu.php'; ?>
<?php
require 'favorite.php';
?>
<?php require './footer.php'; ?>
