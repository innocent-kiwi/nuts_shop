
 <form action="customer-output-tmp.php" method="post">
  <input type="email" name="email" id="">
  <input type="submit" value="仮登録する">
 </form>